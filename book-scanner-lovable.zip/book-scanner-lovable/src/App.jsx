import { useState, useRef, useCallback } from "react";

// ─────────────────────────────────────────────────────────────
//  CONFIGURATION — paste your URLs here after deploying
//  the Cloudflare Worker and Google Apps Script
// ─────────────────────────────────────────────────────────────
const WORKER_URL  = "PASTE_YOUR_CLOUDFLARE_WORKER_URL_HERE";
// e.g. "https://book-scanner.yourname.workers.dev"

const SHEETS_URL  = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_URL_HERE";
// e.g. "https://script.google.com/macros/s/XXXX/exec"
// ─────────────────────────────────────────────────────────────

// ── API CALLS ─────────────────────────────────────────────────
async function callWorker(payload) {
  const res  = await fetch(WORKER_URL, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(payload),
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); }
  catch { throw new Error("Worker error: " + text.substring(0, 100)); }
  if (data.error) throw new Error(data.error.message);
  return data;
}

async function extractBookData(base64, mimeType) {
  const safeType = ["image/jpeg","image/png","image/gif","image/webp"].includes(mimeType)
    ? mimeType : "image/jpeg";
  const data = await callWorker({
    model: "claude-sonnet-4-20250514",
    max_tokens: 1000,
    system: "You are an expert at reading text from book photographs — printed titles, author names, and handwritten labels or stickers in any ink colour. Examine every part of the image including all corners, edges, and spine.",
    messages: [{ role: "user", content: [
      { type: "image", source: { type: "base64", media_type: safeType, data: base64 } },
      { type: "text", text: `Extract from this book photograph:
1. TITLE — exact printed title including subtitle
2. AUTHOR — exact printed author name(s)
3. UNIQUE_ID — any handwritten code on a sticker or label (blue/black ink, any colour). Check all corners and spine.
For each: confidence = high/medium/low and a short note.
Reply ONLY with JSON, no markdown:
{"title":"","title_confidence":"high|medium|low","title_note":"","author":"","author_confidence":"high|medium|low","author_note":"","id":"","id_confidence":"high|medium|low","id_note":""}` }
    ]}],
  });
  const raw = data.content.map(b => b.text || "").join("");
  return JSON.parse(raw.replace(/```json|```/g,"").trim());
}

async function lookupUsedPrice(title, author) {
  const data = await callWorker({
    model: "claude-sonnet-4-20250514",
    max_tokens: 1500,
    tools: [{ type: "web_search_20250305", name: "web_search" }],
    system: `You are a used book price researcher for India. Find SECONDHAND prices ONLY from Indian sellers: Amazon.in (used), OLX.in, Quikr, UsedBooksFactory.com, MyPustak.com, BookVistaa.com. Prices in INR only. If no listing found, search for new MRP and estimate 50% as used price. Always return a suggested_price.`,
    messages: [{ role: "user", content:
      `Find USED/SECONDHAND price in India for: "${title}" by "${author}"
Search 1: "${title} ${author} used second hand buy India INR"
Search 2: "${title} buy preloved India"
Search 3 (if no used listing): "${title} ${author} new price India MRP" then estimate 50%.
Reply ONLY with JSON, no markdown:
{"found":true,"low_price":100,"high_price":300,"suggested_price":200,"new_mrp":399,"sources":[{"name":"Amazon.in Used","price":200,"condition":"Good"}],"note":"explanation","is_estimated":false}`
    }],
  });
  const raw   = data.content.map(b => b.text || "").join("");
  const match = raw.match(/\{[\s\S]*\}/);
  if (!match) throw new Error("Could not parse price data");
  const pr  = JSON.parse(match[0]);
  const enc = encodeURIComponent;
  return {
    ...pr,
    googleUrl:  `https://www.google.com/search?q=${enc(title+" "+author+" used buy India")}&tbm=shop`,
    amazonUrl:  `https://www.amazon.in/s?k=${enc(title+" "+author)}&rh=p_n_condition-type%3A8609962031`,
    olxUrl:     `https://www.olx.in/items/q-${enc(title.replace(/ /g,"-"))}`,
  };
}

async function saveToSheets(record) {
  if (!SHEETS_URL || SHEETS_URL.includes("PASTE_")) return { skipped: true };
  await fetch(SHEETS_URL, {
    method: "POST", mode: "no-cors",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(record),
  });
  return { ok: true };
}

// ── SMALL UI COMPONENTS ───────────────────────────────────────
function StatusBox({ type, children }) {
  const styles = {
    loading: "bg-blue-50 text-blue-800 border-blue-200",
    success: "bg-green-50 text-green-800 border-green-200",
    error:   "bg-red-50  text-red-800  border-red-200",
    warn:    "bg-amber-50 text-amber-800 border-amber-200",
  };
  return (
    <div className={`flex items-start gap-2.5 p-3 rounded-xl border text-sm mt-3 ${styles[type]}`}>
      {type === "loading"
        ? <div className="spinner mt-0.5" />
        : <span className="text-base mt-0.5">{type==="success"?"✅":type==="error"?"❌":"⚠️"}</span>}
      <span className="leading-relaxed">{children}</span>
    </div>
  );
}

function ConfBadge({ conf }) {
  if (!conf) return null;
  const s = {
    high:   "bg-green-100 text-green-800",
    medium: "bg-amber-100 text-amber-800",
    low:    "bg-red-100   text-red-800",
  }[conf] || "bg-slate-100 text-slate-600";
  const label = conf==="high" ? "✓ Confident" : conf==="medium" ? "⚠ Verify" : "✗ Uncertain";
  return <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${s}`}>{label}</span>;
}

function Field({ label, value, onChange, conf, note, placeholder }) {
  const border = conf==="medium"
    ? "border-amber-300 bg-amber-50 focus:border-amber-500"
    : conf==="low"
    ? "border-red-300 bg-red-50 focus:border-red-400"
    : "border-slate-200 bg-slate-50 focus:border-violet-400";
  return (
    <div className="mb-4">
      <div className="flex items-center justify-between mb-1.5">
        <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">{label}</label>
        <ConfBadge conf={conf} />
      </div>
      <input
        type="text"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className={`w-full px-3.5 py-2.5 text-[15px] border-[1.5px] rounded-xl text-slate-900 outline-none transition-colors ${border}`}
      />
      {note && <p className="text-[11px] text-slate-400 mt-1 pl-0.5 leading-snug">ℹ {note}</p>}
    </div>
  );
}

function PriceCard({ priceData, loading, error }) {
  if (loading) return (
    <div className="rounded-xl border border-blue-200 bg-blue-50 p-4 flex items-center gap-3 text-blue-800 text-sm">
      <div className="spinner" />
      Searching Amazon.in Used, OLX, MyPustak, UsedBooksFactory…
    </div>
  );
  if (error) return (
    <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
      <p className="font-semibold mb-1">⚠ Price search failed</p>
      <p className="text-xs leading-relaxed opacity-80">{error}</p>
    </div>
  );
  if (!priceData) return null;
  const { found, suggested_price, low_price, high_price, sources=[], note, is_estimated, googleUrl, amazonUrl, olxUrl } = priceData;
  return (
    <div className={`rounded-xl border p-4 ${found ? "border-green-200 bg-green-50" : "border-amber-200 bg-amber-50"}`}>
      <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
        💰 {is_estimated ? "Estimated Used Price" : "Secondhand Price Found"}
      </p>
      <p className="text-3xl font-bold text-green-700 tracking-tight">₹{suggested_price}</p>
      {(low_price || high_price) && (
        <p className="text-xs text-green-600 mt-0.5 mb-3">Range: ₹{low_price} – ₹{high_price}</p>
      )}
      {sources.length > 0 && (
        <div className="border-t border-green-200 pt-2 mt-2 space-y-1.5">
          {sources.map((s, i) => (
            <div key={i} className="flex justify-between items-center text-xs">
              <span className="text-slate-700 font-medium">{s.name} <span className="text-slate-400 font-normal">({s.condition||"used"})</span></span>
              <span className="text-green-700 font-semibold">₹{s.price}</span>
            </div>
          ))}
        </div>
      )}
      {is_estimated && (
        <p className="text-[11px] text-amber-700 mt-2 bg-amber-100 rounded-lg px-2.5 py-1.5">
          ⚠ No active listing found — estimated at ~50% of new MRP
        </p>
      )}
      {note && <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">ℹ {note}</p>}
      <div className="flex gap-2 mt-3 flex-wrap">
        {[["🔍 Google Shopping", googleUrl], ["📦 Amazon.in Used", amazonUrl], ["🏷 OLX.in", olxUrl]].map(([label, url]) => (
          <a key={label} href={url} target="_blank" rel="noreferrer"
             className="text-[11px] px-3 py-1 bg-white border border-slate-200 rounded-full text-slate-600 hover:bg-slate-50 transition-colors no-underline">
            {label}
          </a>
        ))}
      </div>
    </div>
  );
}

function RecordCard({ record }) {
  return (
    <div className="flex gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
      <span className="text-xl text-violet-400 mt-0.5 flex-shrink-0">📖</span>
      <div className="flex-1 min-w-0">
        <p className="text-[13px] font-semibold text-slate-800 truncate">{record.title}</p>
        <p className="text-[12px] text-slate-500 mt-0.5">{record.author || "—"}</p>
        <div className="flex gap-1.5 flex-wrap mt-1.5">
          <span className="text-[11px] font-medium px-2 py-0.5 bg-violet-100 text-violet-700 rounded-full">{record.id || "no ID"}</span>
          {record.price && <span className="text-[11px] font-medium px-2 py-0.5 bg-green-100 text-green-700 rounded-full">{record.price}</span>}
          <span className="text-[11px] px-2 py-0.5 bg-slate-100 text-slate-500 rounded-full">{record.timestamp}</span>
        </div>
      </div>
    </div>
  );
}

// ── TABS ──────────────────────────────────────────────────────
const TABS = [
  { id: 1, label: "Scan" },
  { id: 2, label: "Verify" },
  { id: 3, label: "Records" },
];

// ── MAIN APP ──────────────────────────────────────────────────
export default function App() {
  const [tab,        setTab]       = useState(1);
  const [imgSrc,     setImgSrc]    = useState(null);
  const [imgBase64,  setImgBase64] = useState(null);
  const [imgMime,    setImgMime]   = useState("image/jpeg");

  // OCR fields
  const [title,      setTitle]     = useState("");
  const [author,     setAuthor]    = useState("");
  const [bookId,     setBookId]    = useState("");
  const [confs,      setConfs]     = useState({});
  const [notes,      setNotes]     = useState({});

  // Price
  const [price,       setPrice]      = useState("");
  const [priceData,   setPriceData]  = useState(null);
  const [priceLoading,setPriceLoading] = useState(false);
  const [priceError,  setPriceError]  = useState(null);

  // Status
  const [scanStatus,  setScanStatus]  = useState(null); // {type, msg}
  const [saveStatus,  setSaveStatus]  = useState(null);
  const [scanLoading, setScanLoading] = useState(false);
  const [saveLoading, setSaveLoading] = useState(false);

  // Records
  const [records, setRecords] = useState([]);

  const fileRef = useRef();

  const resetScan = useCallback(() => {
    setImgSrc(null); setImgBase64(null);
    setScanStatus(null); setSaveStatus(null);
    setPriceData(null); setPriceError(null);
    setPrice(""); setTitle(""); setAuthor(""); setBookId("");
    setConfs({}); setNotes({});
  }, []);

  // ── Image pick ──────────────────────────────────────────────
  const handleFile = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImgMime(file.type || "image/jpeg");
    const reader = new FileReader();
    reader.onload = (ev) => {
      setImgSrc(ev.target.result);
      setImgBase64(ev.target.result.split(",")[1]);
      setScanStatus(null);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  // ── Step 1: OCR ─────────────────────────────────────────────
  const runExtraction = async () => {
    if (!imgBase64) return;
    setScanLoading(true);
    setScanStatus({ type: "loading", msg: "AI is reading the image — scanning title, author, and handwritten ID label…" });
    try {
      const ex = await extractBookData(imgBase64, imgMime);
      setTitle(ex.title  || "");
      setAuthor(ex.author || "");
      setBookId(ex.id     || "");
      setConfs({ title: ex.title_confidence, author: ex.author_confidence, id: ex.id_confidence });
      setNotes({ title: ex.title_note,       author: ex.author_note,       id: ex.id_note });
      setScanStatus({ type: "success", msg: "Extracted — review the fields then search for the secondhand price." });
      setTimeout(() => setTab(2), 700);
    } catch (err) {
      setScanStatus({ type: "error", msg: err.message });
    }
    setScanLoading(false);
  };

  // ── Step 2: Price lookup ─────────────────────────────────────
  const runPriceLookup = async () => {
    if (!title) return;
    setPriceLoading(true); setPriceError(null); setPriceData(null);
    try {
      const pr = await lookupUsedPrice(title, author);
      setPriceData(pr);
      if (pr.suggested_price) setPrice("₹" + pr.suggested_price);
    } catch (err) {
      setPriceError(err.message);
    }
    setPriceLoading(false);
  };

  // ── Step 3: Save ─────────────────────────────────────────────
  const handleSave = async () => {
    if (!title) { setSaveStatus({ type: "error", msg: "Title is required." }); return; }
    setSaveLoading(true);
    setSaveStatus({ type: "loading", msg: "Saving to Google Sheets…" });
    const record = { title, author, id: bookId, price, timestamp: new Date().toLocaleString() };
    try {
      const result = await saveToSheets(record);
      setRecords(prev => [...prev, record]);
      setSaveStatus({
        type: "success",
        msg: result.skipped
          ? "Saved to local records. Add SHEETS_URL to also save to Google Sheets."
          : "Saved to Google Sheets!",
      });
      setTimeout(() => { resetScan(); setTab(1); }, 1500);
    } catch (err) {
      setRecords(prev => [...prev, record]);
      setSaveStatus({ type: "warn", msg: "Saved locally. Could not reach Google Sheets — check your Apps Script URL." });
    }
    setSaveLoading(false);
  };

  // ── CSV Export ───────────────────────────────────────────────
  const exportCSV = () => {
    if (!records.length) return;
    const rows = ["Title,Author,ID,Price (INR),Timestamp",
      ...records.map(r => `"${r.title}","${r.author}","${r.id}","${r.price}","${r.timestamp}"`)
    ].join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([rows], { type: "text/csv" }));
    a.download = "book-records.csv"; a.click();
  };

  // ── RENDER ───────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-slate-100 flex justify-center">
      <div className="w-full max-w-md flex flex-col min-h-screen">

        {/* Header */}
        <div className="bg-slate-900 text-slate-200 px-5 pt-14 pb-5 flex-shrink-0">
          <div className="flex items-center gap-3 mb-1">
            <span className="text-2xl">📚</span>
            <h1 className="text-xl font-semibold tracking-tight text-white">Book Scanner</h1>
          </div>
          <p className="text-[13px] text-slate-500 pl-10">Snap · Extract · Price · Save to Sheets</p>
        </div>

        {/* Tabs */}
        <div className="bg-slate-900 px-5 pb-4 flex gap-2 flex-shrink-0">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex-1 py-2 rounded-full text-[12px] font-medium border transition-all cursor-pointer
                ${tab === t.id
                  ? "bg-slate-800 text-violet-400 border-violet-500"
                  : "bg-transparent text-slate-500 border-slate-700 hover:border-slate-500"}`}>
              <span className="block text-[15px] font-bold">{t.id}</span>
              {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 p-4 overflow-y-auto">

          {/* ── TAB 1: SCAN ── */}
          {tab === 1 && (
            <div className="fade-up space-y-3">
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3.5 text-[12px] text-amber-800 leading-relaxed">
                <span className="font-bold">📷 Tips:</span> Make sure the handwritten ID label is fully in frame. Good light, no glare. Front cover or spine both work fine.
              </div>

              <div className="bg-white rounded-2xl shadow-sm p-4">
                {/* Upload zone */}
                {!imgSrc && (
                  <div onClick={() => fileRef.current.click()}
                    className="border-2 border-dashed border-slate-200 rounded-xl p-10 text-center cursor-pointer hover:border-violet-300 hover:bg-violet-50 transition-all">
                    <span className="text-4xl block mb-3">📷</span>
                    <span className="text-[15px] font-semibold text-slate-700 block mb-1">Tap to photograph book</span>
                    <span className="text-[13px] text-slate-400">Include the handwritten ID label in shot</span>
                  </div>
                )}
                <input ref={fileRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFile} />

                {/* Preview */}
                {imgSrc && (
                  <div className="relative mb-3 rounded-xl overflow-hidden">
                    <img src={imgSrc} alt="Book" className="w-full max-h-64 object-cover" />
                    <button onClick={resetScan}
                      className="absolute top-2 right-2 bg-black/60 text-white text-[11px] px-3 py-1.5 rounded-full cursor-pointer border-0">
                      ↺ Retake
                    </button>
                  </div>
                )}

                {scanStatus && <StatusBox type={scanStatus.type}>{scanStatus.msg}</StatusBox>}

                <button onClick={runExtraction} disabled={!imgBase64 || scanLoading}
                  className="w-full mt-3 py-3.5 bg-slate-900 text-white rounded-xl text-[15px] font-semibold
                             disabled:bg-slate-200 disabled:text-slate-400 cursor-pointer disabled:cursor-not-allowed
                             hover:bg-slate-700 active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                  {scanLoading ? <><div className="spinner" /> Analysing…</> : "🔍 Analyse with AI"}
                </button>
              </div>
            </div>
          )}

          {/* ── TAB 2: VERIFY + PRICE ── */}
          {tab === 2 && (
            <div className="fade-up">
              <div className="bg-white rounded-2xl shadow-sm p-4">
                <p className="text-[13px] text-slate-500 leading-relaxed mb-4">
                  AI has read your image.{" "}
                  <span className="text-amber-700 font-semibold">Yellow = verify</span>,{" "}
                  <span className="text-red-700 font-semibold">red = not found</span> — correct manually before saving.
                </p>

                <Field label="📖 Book Title"  value={title}  onChange={setTitle}  conf={confs.title}  note={notes.title}  placeholder="Book title" />
                <Field label="✍️ Author"       value={author} onChange={setAuthor} conf={confs.author} note={notes.author} placeholder="Author name" />
                <Field label="🏷️ Unique ID"    value={bookId} onChange={setBookId} conf={confs.id}     note={notes.id}     placeholder="e.g. T-26-35" />

                <hr className="border-slate-100 my-4" />

                {/* Price Section */}
                <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-3">💰 Used Book Price (INR)</p>

                <button onClick={runPriceLookup} disabled={!title || priceLoading}
                  className="w-full py-2.5 mb-3 bg-slate-50 border border-slate-200 rounded-xl text-[13px] font-medium text-slate-700
                             hover:bg-violet-50 hover:border-violet-300 hover:text-violet-700
                             disabled:opacity-50 disabled:cursor-not-allowed
                             flex items-center justify-center gap-2 cursor-pointer transition-all">
                  {priceLoading ? <><div className="spinner" /> Searching Indian used book sellers…</> : "🔎 Search secondhand price in India"}
                </button>

                <PriceCard priceData={priceData} loading={false} error={priceError} />

                {(priceData || priceError) && (
                  <div className="mt-3">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">₹ Price — edit if needed</label>
                    <input type="text" value={price} onChange={e => setPrice(e.target.value)}
                      placeholder="e.g. ₹200"
                      className="w-full px-3.5 py-2.5 text-[15px] border-[1.5px] border-slate-200 rounded-xl bg-slate-50 text-slate-900 outline-none focus:border-violet-400 transition-colors" />
                  </div>
                )}

                <hr className="border-slate-100 my-4" />

                <button onClick={handleSave} disabled={saveLoading}
                  className="w-full py-3.5 bg-green-700 text-white rounded-xl text-[15px] font-semibold
                             hover:bg-green-600 active:scale-[0.98]
                             disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed
                             flex items-center justify-center gap-2 cursor-pointer transition-all">
                  {saveLoading ? <><div className="spinner" /> Saving…</> : "📊 Save to Google Sheets"}
                </button>

                <button onClick={() => { resetScan(); setTab(1); }}
                  className="w-full mt-2 py-3 bg-transparent border border-slate-200 text-slate-600 rounded-xl text-[14px] font-medium cursor-pointer hover:bg-slate-50 transition-colors">
                  ← Scan another book
                </button>

                {saveStatus && <StatusBox type={saveStatus.type}>{saveStatus.msg}</StatusBox>}

                {(!SHEETS_URL || SHEETS_URL.includes("PASTE_")) && (
                  <p className="text-[11px] text-slate-400 mt-3 text-center leading-snug">
                    Google Sheets not connected yet — add your Apps Script URL in config to enable live saving.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* ── TAB 3: RECORDS ── */}
          {tab === 3 && (
            <div className="fade-up">
              <div className="bg-white rounded-2xl shadow-sm p-4">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-[15px] font-semibold text-slate-800">Scanned Books</h2>
                  <span className="text-[11px] font-semibold bg-slate-900 text-violet-400 px-3 py-0.5 rounded-full">
                    {records.length}
                  </span>
                </div>

                {records.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 text-[13px]">
                    <span className="text-3xl block mb-2 opacity-30">📚</span>
                    No books scanned yet
                  </div>
                ) : (
                  <div className="space-y-2">
                    {records.map((r, i) => <RecordCard key={i} record={r} />)}
                  </div>
                )}

                <button onClick={exportCSV} disabled={!records.length}
                  className="w-full mt-4 py-3 bg-transparent border border-slate-200 text-slate-600 rounded-xl text-[14px] font-medium
                             cursor-pointer hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                  ↓ Export CSV
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
