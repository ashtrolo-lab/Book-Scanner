// ─────────────────────────────────────────────────────────────
//  BOOK SCANNER — Configuration
//  Fill in both values before deploying on Lovable
// ─────────────────────────────────────────────────────────────

// 1. Your Cloudflare Worker URL (proxy for Anthropic API)
//    Deploy cloudflare-worker.js first → copy the URL here
export const WORKER_URL = "PASTE_YOUR_CLOUDFLARE_WORKER_URL_HERE";

// 2. Your Google Apps Script Web App URL (saves to Google Sheets)
//    Follow the Google Sheets setup guide → copy the URL here
export const SHEETS_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_URL_HERE";
